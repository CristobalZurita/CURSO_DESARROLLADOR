// =========================
// script.js
// =========================

const formulario = document.getElementById("registroForm");
const botonLimpiar = document.getElementById("btnLimpiar");
const mensaje = document.getElementById("mensaje");
const tablaBody = document.querySelector("#tablaRegistros tbody");

const inputNombre = document.getElementById("nombre");
const inputCorreo = document.getElementById("correo");
const inputTelefono = document.getElementById("telefono");
const inputEdad = document.getElementById("edad");
const selectPais = document.getElementById("codigoPais");

const errorNombre = document.getElementById("errorNombre");
const errorCorreo = document.getElementById("errorCorreo");
const errorTelefono = document.getElementById("errorTelefono");
const errorEdad = document.getElementById("errorEdad");

// =========================
// REGLAS TELEFÓNICAS POR PAÍS
// =========================
const reglasTelefono = {
    "+56":  { pais: "Chile", digitos: 8, formato: "9 4562 1234" },
    "+54":  { pais: "Argentina", digitos: 10, formato: "11 4562 1234" },
    "+57":  { pais: "Colombia", digitos: 10, formato: "300 123 4567" },
    "+51":  { pais: "Perú", digitos: 9, formato: "912 345 678" },
    "+52":  { pais: "México", digitos: 10, formato: "55 1234 5678" },
    "+55":  { pais: "Brasil", digitos: 11, formato: "11 91234 5678" },
    "+53":  { pais: "Cuba", digitos: 8, formato: "5 123 4567" },
    "+58":  { pais: "Venezuela", digitos: 10, formato: "412 123 4567" },
    "+591": { pais: "Bolivia", digitos: 8, formato: "7 123 4567" },
    "+595": { pais: "Paraguay", digitos: 9, formato: "981 123 456" },
    "+598": { pais: "Uruguay", digitos: 8, formato: "91 234 567" },
    "+593": { pais: "Ecuador", digitos: 9, formato: "98 765 4321" },
    "+502": { pais: "Guatemala", digitos: 8, formato: "5123 4567" },
    "+503": { pais: "El Salvador", digitos: 8, formato: "7123 4567" },
    "+504": { pais: "Honduras", digitos: 8, formato: "9123 4567" },
    "+505": { pais: "Nicaragua", digitos: 8, formato: "8123 4567" },
    "+506": { pais: "Costa Rica", digitos: 8, formato: "8123 4567" },
    "+507": { pais: "Panamá", digitos: 8, formato: "6123 4567" },

    "+1":   { pais: "Estados Unidos / Canadá", digitos: 10, formato: "202 555 0123" },

    "+34":  { pais: "España", digitos: 9, formato: "612 345 678" },
    "+33":  { pais: "Francia", digitos: 9, formato: "6 12 34 56 78" },
    "+351": { pais: "Portugal", digitos: 9, formato: "912 345 678" },
    "+44":  { pais: "Reino Unido", digitos: 10, formato: "7400 123456" },
    "+49":  { pais: "Alemania", digitos: 11, formato: "151 2345 6789" },

    "+81":  { pais: "Japón", digitos: 10, formato: "090 1234 5678" },
    "+82":  { pais: "Corea del Sur", digitos: 10, formato: "010 1234 5678" },
    "+86":  { pais: "China", digitos: 11, formato: "138 0013 8000" },
    "+91":  { pais: "India", digitos: 10, formato: "91234 56789" },

    "+90":  { pais: "Turquía", digitos: 10, formato: "501 234 5678" },
    "+971": { pais: "Emiratos Árabes Unidos", digitos: 9, formato: "50 123 4567" },
    "+972": { pais: "Israel", digitos: 9, formato: "52 123 4567" },
    "+966": { pais: "Arabia Saudita", digitos: 9, formato: "50 123 4567" }
};

// =========================
// UTILIDADES DE ERROR
// =========================
function mostrarError(input, span, texto) {
    input.classList.add("error-input");
    span.textContent = texto;
}

function limpiarError(input, span) {
    input.classList.remove("error-input");
    span.textContent = "";
}

// =========================
// VALIDACIONES DE TEXTO
// =========================
const LETRAS_VALIDAS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";

function detectarCaracterInvalido(texto) {
    for (let c of texto) {
        if (!LETRAS_VALIDAS.includes(c)) return c;
    }
    return null;
}

// =========================
// TELÉFONO EN TIEMPO REAL
// =========================
function aplicarReglaTelefono() {
    const regla = reglasTelefono[selectPais.value];
    let valor = inputTelefono.value.replace(/\D/g, "");

    if (regla) {
        valor = valor.slice(0, regla.digitos);
        inputTelefono.placeholder = regla.formato;
    }

    inputTelefono.value = valor;
}

inputTelefono.addEventListener("input", aplicarReglaTelefono);
selectPais.addEventListener("change", aplicarReglaTelefono);

// =========================
// SUBMIT
// =========================
formulario.addEventListener("submit", function (e) {
    e.preventDefault();

    let hayErrores = false;

    const nombre = inputNombre.value.trim();
    const correo = inputCorreo.value.trim();
    const telefono = inputTelefono.value.trim();
    const edad = inputEdad.value.trim();
    const codigo = selectPais.value;
    const regla = reglasTelefono[codigo];

    limpiarError(inputNombre, errorNombre);
    limpiarError(inputCorreo, errorCorreo);
    limpiarError(inputTelefono, errorTelefono);
    limpiarError(inputEdad, errorEdad);

    // ===== NOMBRE =====
    const invalido = detectarCaracterInvalido(nombre);
    if (!nombre || invalido) {
        mostrarError(
            inputNombre,
            errorNombre,
            invalido ? `Carácter no permitido: "${invalido}"` : "Nombre requerido"
        );
        hayErrores = true;
    }

    // ===== CORREO =====
    if (!/^[A-Za-z0-9]+@[A-Za-z0-9]+\.[A-Za-z]{2,}$/.test(correo)) {
        mostrarError(inputCorreo, errorCorreo, "Correo inválido");
        hayErrores = true;
    }

    // ===== TELÉFONO =====
    if (!regla || telefono.length !== regla.digitos) {
        mostrarError(
            inputTelefono,
            errorTelefono,
            `Debe tener ${regla.digitos} dígitos`
        );
        hayErrores = true;
    }

    // ===== EDAD =====
    if (!/^\d+$/.test(edad) || edad < 18 || edad > 120) {
        mostrarError(inputEdad, errorEdad, "Edad no válida (18–120)");
        hayErrores = true;
    }

    if (hayErrores) return;

    // ===== REGISTRO =====
    const fila = document.createElement("tr");
    fila.innerHTML = `
        <td>${nombre}</td>
        <td>${correo}</td>
        <td>${regla.pais} (${codigo}) ${telefono}</td>
        <td>${edad}</td>
    `;
    tablaBody.appendChild(fila);

    mensaje.textContent =
        "Usted se ha comunicado con Cirujano de Sintetizadores. " +
        "Hemos recibido correctamente su mensaje y nos pondremos en contacto con usted a la brevedad.";
    mensaje.style.color = "#ec6b00";

    formulario.reset();
    aplicarReglaTelefono();
});

// =========================
// LIMPIAR
// =========================
botonLimpiar.addEventListener("click", function () {
    formulario.reset();
    mensaje.textContent = "";
    limpiarError(inputNombre, errorNombre);
    limpiarError(inputCorreo, errorCorreo);
    limpiarError(inputTelefono, errorTelefono);
    limpiarError(inputEdad, errorEdad);
    aplicarReglaTelefono();
});
