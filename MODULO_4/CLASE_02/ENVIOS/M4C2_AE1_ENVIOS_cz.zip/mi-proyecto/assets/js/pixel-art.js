export function initPixelCharacters() {
  // Pixel sprites are now defined entirely in SCSS.
}
