/**
 * Basketball Tournament Registration
 * app.js — Lógica principal de la aplicación
 *
 * Variables, validaciones, condicionales y manejo de lista
 */

'use strict';

// =============================================================================
// ESTADO GLOBAL
// =============================================================================

/** @type {Array<Object>} Lista de jugadores registrados */
let jugadores = [];

/** Posiciones válidas del básquetbol */
const POSICIONES_VALIDAS = ['base', 'escolta', 'alero', 'ala-pivot', 'pivot'];

/** Requisitos mínimos de inscripción */
const REQUISITOS = {
  edadMinima: 16,          // Edad mínima para registrarse
  edadAdulto: 18,          // Corte categoría adulto (>= 18)
  alturaMinima: 160        // Altura mínima en cm (se registra igual pero se notifica)
};

// =============================================================================
// ELEMENTOS DEL DOM
// =============================================================================

const form          = document.getElementById('form-registro');
const inputNombre   = document.getElementById('nombre');
const inputEdad     = document.getElementById('edad');
const inputAltura   = document.getElementById('altura');
const selectPos     = document.getElementById('posicion');
const playersList   = document.getElementById('players-list');
const countBadge    = document.getElementById('count-badge');
const statTotal     = document.getElementById('stat-total');
const statAdultos   = document.getElementById('stat-adultos');
const statJuveniles = document.getElementById('stat-juveniles');
const btnClear      = document.getElementById('btn-clear');
const btnTeams      = document.getElementById('btn-teams');
const modalOverlay  = document.getElementById('modal-equipos');
const modalClose    = document.getElementById('modal-close');
const teamAdultoList   = document.getElementById('team-adulto-list');
const teamJuvenilList  = document.getElementById('team-juvenil-list');
const teamAdultoCount  = document.getElementById('team-adulto-count');
const teamJuvenilCount = document.getElementById('team-juvenil-count');

// =============================================================================
// VALIDACIONES
// =============================================================================

/**
 * Valida el nombre del jugador
 * @param {string} nombre
 * @returns {{ valid: boolean, message: string }}
 */
function validarNombre(nombre) {
  if (!nombre || nombre.trim() === '') {
    return { valid: false, message: 'El nombre no puede estar vacío.' };
  }
  if (typeof nombre !== 'string' || nombre.trim().length < 2) {
    return { valid: false, message: 'El nombre debe tener al menos 2 caracteres.' };
  }
  if (nombre.trim().length > 60) {
    return { valid: false, message: 'El nombre es demasiado largo.' };
  }
  return { valid: true, message: '' };
}

/**
 * Valida la edad del jugador
 * @param {string|number} edad
 * @returns {{ valid: boolean, message: string }}
 */
function validarEdad(edad) {
  if (edad === '' || edad === null || edad === undefined) {
    return { valid: false, message: 'La edad no puede estar vacía.' };
  }

  const edadNum = Number(edad);

  if (isNaN(edadNum) || !Number.isInteger(edadNum)) {
    return { valid: false, message: 'La edad debe ser un número entero válido.' };
  }

  if (edadNum < REQUISITOS.edadMinima) {
    return { valid: false, message: `Edad mínima para participar: ${REQUISITOS.edadMinima} años.` };
  }

  if (edadNum > 65) {
    return { valid: false, message: 'Por favor ingrese una edad válida (máx. 65).' };
  }

  return { valid: true, message: '' };
}

/**
 * Valida la altura del jugador
 * @param {string|number} altura
 * @returns {{ valid: boolean, message: string, warning?: string }}
 */
function validarAltura(altura) {
  if (altura === '' || altura === null || altura === undefined) {
    return { valid: false, message: 'La altura no puede estar vacía.' };
  }

  const alturaNum = Number(altura);

  if (isNaN(alturaNum)) {
    return { valid: false, message: 'Ingrese una altura válida en cm.' };
  }

  if (alturaNum < 100 || alturaNum > 250) {
    return { valid: false, message: 'Altura debe ser entre 100 y 250 cm.' };
  }

  // Se registra igual, pero se notifica si está bajo el mínimo recomendado
  if (alturaNum < REQUISITOS.alturaMinima) {
    return {
      valid: true,
      message: '',
      warning: `Altura bajo el mínimo recomendado (${REQUISITOS.alturaMinima} cm), pero se registrará.`
    };
  }

  return { valid: true, message: '' };
}

/**
 * Valida la posición del jugador
 * @param {string} posicion
 * @returns {{ valid: boolean, message: string }}
 */
function validarPosicion(posicion) {
  if (!posicion || posicion === '') {
    return { valid: false, message: 'Selecciona una posición.' };
  }

  if (!POSICIONES_VALIDAS.includes(posicion)) {
    return { valid: false, message: `Posición inválida. Opciones: ${POSICIONES_VALIDAS.join(', ')}.` };
  }

  return { valid: true, message: '' };
}

// =============================================================================
// LÓGICA DE CLASIFICACIÓN
// =============================================================================

/**
 * Determina la categoría del jugador según su edad
 * @param {number} edad
 * @returns {'adulto'|'juvenil'}
 */
function determinarCategoria(edad) {
  return edad >= REQUISITOS.edadAdulto ? 'adulto' : 'juvenil';
}

/**
 * Verifica si el jugador cumple los requisitos mínimos
 * @param {Object} jugador
 * @returns {{ aprobado: boolean, motivos: string[] }}
 */
function verificarRequisitos(jugador) {
  const motivos = [];

  if (jugador.edad < REQUISITOS.edadMinima) {
    motivos.push(`Edad insuficiente (mínimo ${REQUISITOS.edadMinima} años)`);
  }

  if (!POSICIONES_VALIDAS.includes(jugador.posicion)) {
    motivos.push('Posición no válida');
  }

  return {
    aprobado: motivos.length === 0,
    motivos
  };
}

// =============================================================================
// REGISTRO DE JUGADOR
// =============================================================================

/**
 * Registra un nuevo jugador con validación completa
 * @param {Object} datos - Datos del formulario
 */
function registrarJugador(datos) {
  // Declarar variables con los datos ingresados
  const nombre   = datos.nombre.trim();
  const edad     = Number(datos.edad);
  const altura   = Number(datos.altura);
  const posicion = datos.posicion;

  // Clasificar por categoría (condicional)
  const categoria = determinarCategoria(edad);

  // Verificar requisitos
  const { aprobado, motivos } = verificarRequisitos({ nombre, edad, altura, posicion });

  // Construir objeto jugador
  const jugador = {
    id: Date.now(),
    numero: jugadores.length + 1,
    nombre,
    edad,
    altura,
    posicion,
    categoria,
    aprobado,
    motivos,
    timestamp: new Date().toLocaleTimeString('es-CL')
  };

  // Agregar a la lista
  jugadores.push(jugador);

  // Actualizar UI
  renderizarJugador(jugador, true);
  actualizarStats();

  // Notificación
  if (aprobado) {
    showToast(`✅ ${nombre.toUpperCase()} registrado como ${categoria.toUpperCase()}`, 'success');
  } else {
    showToast(`⚠️ ${nombre.toUpperCase()} registrado con observaciones`, 'error');
  }
}

// =============================================================================
// RENDER DE JUGADORES
// =============================================================================

/**
 * Genera chip de posición con clase CSS
 * @param {string} posicion
 * @returns {string} HTML del chip
 */
function positionChip(posicion) {
  const claseMap = {
    'base': 'pos-base',
    'escolta': 'pos-escolta',
    'alero': 'pos-alero',
    'ala-pivot': 'pos-ala-pivot',
    'pivot': 'pos-pivot'
  };
  const cls = claseMap[posicion] || 'pos-base';
  return `<span class="pos-chip ${cls}">${posicion}</span>`;
}

/**
 * Renderiza una card de jugador en la lista
 * @param {Object} jugador
 * @param {boolean} animate - Si se aplica animación de "just added"
 */
function renderizarJugador(jugador, animate = false) {
  // Limpiar el empty state si existe
  const emptyState = playersList.querySelector('.empty-state');
  if (emptyState) emptyState.remove();

  const estadoClass  = jugador.aprobado ? 'player-card--ok' : 'player-card--rejected';
  const catClass     = `cat-${jugador.categoria}`;
  const estadoText   = jugador.aprobado ? '● INSCRITO' : '● OBSERVADO';
  const statusExtra  = jugador.motivos.length > 0
    ? `<small style="color:#fb3c19;font-size:0.65rem;display:block;margin-top:2px">${jugador.motivos.join(' | ')}</small>`
    : '';
  const animClass    = animate ? ' just-added' : '';

  const card = document.createElement('div');
  card.className = `player-card ${estadoClass}${animClass}`;
  card.dataset.id = jugador.id;

  card.innerHTML = `
    <div class="player-number">${String(jugador.numero).padStart(2, '0')}</div>
    <div class="player-info">
      <div class="player-name">${jugador.nombre}</div>
      <div class="player-details">
        <span class="player-detail">Edad: <span>${jugador.edad} años</span></span>
        <span class="player-detail">Altura: <span>${jugador.altura} cm</span></span>
        <span class="player-detail">Pos: ${positionChip(jugador.posicion)}</span>
      </div>
      ${statusExtra}
    </div>
    <div class="player-meta">
      <span class="player-category ${catClass}">${jugador.categoria.toUpperCase()}</span>
      <span class="player-status">${estadoText}</span>
      <span style="font-family:'Share Tech Mono';font-size:0.6rem;color:#728aa5;">${jugador.timestamp}</span>
    </div>
  `;

  playersList.prepend(card);

  // Remover clase de animación especial
  if (animate) {
    setTimeout(() => card.classList.remove('just-added'), 1400);
  }
}

/**
 * Renderiza el estado vacío de la lista
 */
function renderizarEmpty() {
  playersList.innerHTML = `
    <div class="empty-state">
      <span class="empty-icon">🏀</span>
      <p>No hay jugadores registrados aún.</p>
      <p style="margin-top:8px;font-size:0.7rem;opacity:0.5">Completa el formulario para agregar jugadores.</p>
    </div>
  `;
}

// =============================================================================
// STATS DEL HEADER
// =============================================================================

function actualizarStats() {
  const total      = jugadores.length;
  const adultos    = jugadores.filter(j => j.categoria === 'adulto').length;
  const juveniles  = jugadores.filter(j => j.categoria === 'juvenil').length;

  statTotal.textContent     = String(total).padStart(2, '0');
  statAdultos.textContent   = String(adultos).padStart(2, '0');
  statJuveniles.textContent = String(juveniles).padStart(2, '0');
  countBadge.textContent    = total;
}

// =============================================================================
// EQUIPOS
// =============================================================================

/**
 * Arma y muestra los equipos por categoría en el modal
 */
function mostrarEquipos() {
  const inscritos = jugadores.filter(j => j.aprobado);
  const adultos   = inscritos.filter(j => j.categoria === 'adulto');
  const juveniles = inscritos.filter(j => j.categoria === 'juvenil');

  if (inscritos.length === 0) {
    showToast('Sin jugadores inscritos para armar equipos.', 'info');
    return;
  }

  // Render adultos
  teamAdultoCount.textContent = `${adultos.length} jugadores`;
  teamAdultoList.innerHTML = adultos.length > 0
    ? adultos.map((j, i) => teamPlayerItem(j, i + 1)).join('')
    : '<div class="team-empty">Sin jugadores adultos inscritos</div>';

  // Render juveniles
  teamJuvenilCount.textContent = `${juveniles.length} jugadores`;
  teamJuvenilList.innerHTML = juveniles.length > 0
    ? juveniles.map((j, i) => teamPlayerItem(j, i + 1)).join('')
    : '<div class="team-empty">Sin jugadores juveniles inscritos</div>';

  // Abrir modal
  modalOverlay.classList.add('is-active');
}

/**
 * Genera HTML de item de jugador en la vista de equipos
 */
function teamPlayerItem(jugador, index) {
  return `
    <div class="team-player-item">
      <span class="item-num">#${String(index).padStart(2,'0')}</span>
      <span class="item-name">${jugador.nombre}</span>
      <span class="item-pos">${jugador.posicion}</span>
      <span class="item-age">${jugador.edad}a</span>
    </div>
  `;
}

// =============================================================================
// LIMPIAR LISTA
// =============================================================================

function limpiarLista() {
  if (jugadores.length === 0) {
    showToast('La lista ya está vacía.', 'info');
    return;
  }

  if (!confirm('¿Seguro que deseas limpiar toda la lista de jugadores?')) return;

  jugadores = [];
  renderizarEmpty();
  actualizarStats();
  showToast('Lista de jugadores limpiada.', 'info');
}

// =============================================================================
// TOAST / NOTIFICACIONES
// =============================================================================

let toastTimeout = null;

/**
 * Muestra una notificación temporal
 * @param {string} mensaje
 * @param {'success'|'error'|'info'} tipo
 */
function showToast(mensaje, tipo = 'info') {
  // Remover toast anterior
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  if (toastTimeout) clearTimeout(toastTimeout);

  const toast = document.createElement('div');
  toast.className = `toast toast--${tipo}`;
  toast.textContent = mensaje;
  document.body.appendChild(toast);

  toastTimeout = setTimeout(() => {
    toast.classList.add('fade-out');
    setTimeout(() => toast.remove(), 350);
  }, 3200);
}

// =============================================================================
// MANEJO DE ERRORES EN FORMULARIO
// =============================================================================

/**
 * Muestra error en un campo
 */
function setError(input, errorId, message) {
  input.classList.add('is-invalid');
  const errorEl = document.getElementById(errorId);
  if (errorEl) errorEl.textContent = message;
}

/**
 * Limpia el error de un campo
 */
function clearError(input, errorId) {
  input.classList.remove('is-invalid');
  const errorEl = document.getElementById(errorId);
  if (errorEl) errorEl.textContent = '';
}

/**
 * Valida todo el formulario
 * @returns {boolean} true si es válido
 */
function validarFormulario() {
  let isValid = true;

  // Validar nombre
  const vnombre = validarNombre(inputNombre.value);
  if (!vnombre.valid) {
    setError(inputNombre, 'error-nombre', vnombre.message);
    isValid = false;
  } else {
    clearError(inputNombre, 'error-nombre');
  }

  // Validar edad
  const vedad = validarEdad(inputEdad.value);
  if (!vedad.valid) {
    setError(inputEdad, 'error-edad', vedad.message);
    isValid = false;
  } else {
    clearError(inputEdad, 'error-edad');
  }

  // Validar altura
  const valtura = validarAltura(inputAltura.value);
  if (!valtura.valid) {
    setError(inputAltura, 'error-altura', valtura.message);
    isValid = false;
  } else {
    clearError(inputAltura, 'error-altura');
    if (valtura.warning) {
      showToast(`⚠️ ${valtura.warning}`, 'info');
    }
  }

  // Validar posición
  const vpos = validarPosicion(selectPos.value);
  if (!vpos.valid) {
    setError(selectPos, 'error-posicion', vpos.message);
    isValid = false;
  } else {
    clearError(selectPos, 'error-posicion');
  }

  return isValid;
}

// =============================================================================
// EVENT LISTENERS
// =============================================================================

// Submit del formulario
form.addEventListener('submit', (e) => {
  e.preventDefault();

  if (!validarFormulario()) return;

  registrarJugador({
    nombre:   inputNombre.value,
    edad:     inputEdad.value,
    altura:   inputAltura.value,
    posicion: selectPos.value
  });

  form.reset();
  inputNombre.focus();
});

// Limpiar errores en tiempo real
inputNombre.addEventListener('input', () => clearError(inputNombre, 'error-nombre'));
inputEdad.addEventListener('input',   () => clearError(inputEdad, 'error-edad'));
inputAltura.addEventListener('input', () => clearError(inputAltura, 'error-altura'));
selectPos.addEventListener('change',  () => clearError(selectPos, 'error-posicion'));

// Botón limpiar lista
btnClear.addEventListener('click', limpiarLista);

// Botón armar equipos
btnTeams.addEventListener('click', mostrarEquipos);

// Cerrar modal
modalClose.addEventListener('click', () => modalOverlay.classList.remove('is-active'));
modalOverlay.addEventListener('click', (e) => {
  if (e.target === modalOverlay) modalOverlay.classList.remove('is-active');
});

// Cerrar modal con ESC
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') modalOverlay.classList.remove('is-active');
});

// =============================================================================
// INIT
// =============================================================================

(function init() {
  renderizarEmpty();
  actualizarStats();
  inputNombre.focus();
})();
